package com.example.aqua;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class undian_extravaganza extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_undian_extravaganza);

        // Ambil nilai yang dikirim dari aktivitas sebelumnya
        String result = getIntent().getStringExtra("result");

        // Tampilkan hasil di TextView
        TextView resultTextView = findViewById(R.id.resultTextView);
        resultTextView.setText(result);
    }
}