package com.example.aqua;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class bagiandalam extends AppCompatActivity {

    private ImageButton menu_btn;

    private ImageButton mau_scan;

    private ImageButton kode;

    private ImageButton to_redeem;

    private ImageButton to_extra;

    private ImageButton to_royal;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bagiandalam);
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.navigation_view);

        navigationView.setNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.logout) {
                Intent intent1 = new Intent(bagiandalam.this, MainActivity.class);
                startActivity(intent1);
            }

            drawerLayout.closeDrawers();
            return true;

        });

        TextView textViewPoints = findViewById(R.id.textViewPoints);
        int userPoints = UserPointsManager.getUserPoints(this);
        textViewPoints.setText(String.valueOf(userPoints));

        mau_scan=findViewById(R.id.mau_scan);
        mau_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(bagiandalam.this, scanqr.class);
                startActivity(intent);
            }
        });

        kode=findViewById(R.id.kode);
        kode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(bagiandalam.this, scanqr.class);
                startActivity(intent);
            }
        });

        to_redeem=findViewById(R.id.to_redeem);
        to_redeem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(bagiandalam.this, redeemvaganza.class);
                startActivity(intent);
            }
        });

        to_extra=findViewById(R.id.to_extra);
        to_extra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(bagiandalam.this, extravaganza.class);
                startActivity(intent);
            }
        });

        to_royal=findViewById(R.id.to_royal);
        to_royal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(bagiandalam.this, royalvaganza.class);
                startActivity(intent);
            }
        });

    }
    public void tampilkanMenu(View view) {
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
            drawerLayout.closeDrawer(GravityCompat.END);
        } else {
            drawerLayout.openDrawer(GravityCompat.END);
        }
    }
}