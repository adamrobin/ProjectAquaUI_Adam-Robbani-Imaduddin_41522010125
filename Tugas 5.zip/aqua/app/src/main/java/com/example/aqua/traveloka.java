package com.example.aqua;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class traveloka extends AppCompatActivity {

    private TextView textViewtotal5;
    private TextView textViewTotalNeededPoints;
    private int points5 = 1;

    private Button redeem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_traveloka);

        textViewtotal5 = findViewById(R.id.textViewtotal5);
        textViewTotalNeededPoints = findViewById(R.id.accumulation);
        updatePointsDisplay();

        redeem=findViewById(R.id.button_redeem);
        redeem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(traveloka.this, bagiandalam.class);
                startActivity(intent);
            }
        });
    }

    public void increasetotal5(View view) {
        points5++;
        updatePointsDisplay();
    }

    public void decreasetotal5(View view) {
        points5--;
        updatePointsDisplay();
    }

    private void updatePointsDisplay() {
        textViewtotal5.setText(String.valueOf(points5));

        // Hitung total poin yang diperlukan untuk melakukan redeem
        int neededPoints = points5 * 200;

        // Tampilkan total poin yang diperlukan pada TextView baru
        textViewTotalNeededPoints.setText(String.valueOf(neededPoints));
    }
}